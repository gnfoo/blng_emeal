<?php

class Add_Travel_Fields {

	/**
	 * Make changes to the database.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('leave',function($table){
			$table->string('destination',50);
			$table->string('dep_airport',50);
			$table->string('arr_airport',50);
			$table->string('hotel',50);
			$table->date('checkin',50);
			$table->date('checkout',50);
			$table->string('travel_ins_req',1);
			$table->string('visa_req',1);
			$table->decimal('allowance',10,2);
			$table->decimal('accomodation',10,2);
			$table->decimal('transportation',10,2);
			$table->decimal('other_exp1',10,2);
			$table->decimal('other_exp2',10,2);
			$table->decimal('est_budget',10,2);
			$table->decimal('allowance_total',10,2);
			$table->decimal('accomodation_total',10,2);
			$table->decimal('transportation_total',10,2);
			$table->decimal('other_exp1_total',10,2);
			$table->decimal('other_exp2_total',10,2);
			$table->decimal('est_budget_total',10,2);
		});
	}

	/**
	 * Revert the changes to the database.
	 *
	 * @return void
	 */
	public function down()
	{	
		Schema::table('leave',function($table){
			$table->drop_column('destination');
			$table->drop_column('dep_airport');
			$table->drop_column('arr_airport');
			$table->drop_column('hotel');
			$table->drop_column('checkin');
			$table->drop_column('checkout');
			$table->drop_column('travel_ins_req');
			$table->drop_column('visa_req');
			$table->drop_column('allowance');
			$table->drop_column('accomodation');
			$table->drop_column('transportation');
			$table->drop_column('other_exp1');
			$table->drop_column('other_exp2');
			$table->drop_column('est_budget');
			$table->drop_column('allowance_total');
			$table->drop_column('accomodation_total');
			$table->drop_column('transportation_total');
			$table->drop_column('other_exp1_total');
			$table->drop_column('other_exp2_total');
			$table->drop_column('est_budget_total');
		});
	}

}