<?php

class Create_Salaries_Table {

	/**
	 * Make changes to the database.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('salaries',function($table){
			$table->increments('id');
			$table->date('salary_date');
			$table->decimal('base',10,2);
			$table->decimal('allow',10,2);
			$table->decimal('tap',10,2);
			$table->decimal('scp',10,2);
			$table->decimal('deductions',10,2);
			$table->timestamps();

		});
	}

	/**
	 * Revert the changes to the database.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('salaries');
	}

}