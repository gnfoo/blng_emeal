<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Simply tell Laravel the HTTP verbs and URIs it should respond to. It is a
| breeze to setup your application using Laravel's RESTful routing and it
| is perfectly suited for building large applications and simple APIs.
|
| Let's respond to a simple GET request to http://example.com/hello:
|
|		Route::get('hello', function()
|		{
|			return 'Hello World!';
|		});
|
| You can even respond to more than one URI:
|
|		Route::post(array('hello', 'world'), function()
|		{
|			return 'Hello World!';
|		});
|
| It's easy to allow URI wildcards using (:num) or (:any):
|
|		Route::put('hello/(:any)', function($name)
|		{
|			return "Welcome, $name.";
|		});
|
*/
Route::get('/', 'user@index');
Route::get('/admin', 'login@index');

Route::get('user/(:any)/(:any)',array('as'=>'user','uses'=>'user@index'));


Route::get('login',array('as'=>'login','uses'=>'login@index'));
Route::get('login/retrieve',array('as'=>'login_retrieve','uses'=>'login@retrieve'));
Route::post('login/process',array('uses'=>'login@process'));
Route::post('login/process_retrieve',array('uses'=>'login@process_retrieve'));
Route::get('login/logout',array('as'=>'logout','uses'=>'login@logout'));

Route::get('admin/members_list',array('as'=>'admin_members_list','uses'=>'admin@members_list'));
Route::get('admin/members_list_archive',array('as'=>'admin_members_list_archive','uses'=>'admin@members_list_archive'));
Route::get('admin/search_members/(:any)',array('as'=>'admin_search_members','uses'=>'admin@search_members'));
Route::get('admin/admins_list',array('as'=>'admin_admins_list','uses'=>'admin@admins_list'));
Route::get('admin/vendors_list',array('as'=>'admin_vendors_list','uses'=>'admin@vendors_list'));
Route::get('admin/working_days_list',array('as'=>'admin_working_days_list','uses'=>'admin@working_days_list'));
Route::get('admin/transactions_list',array('as'=>'admin_transactions_list','uses'=>'admin@transactions_list'));
Route::get('admin/month_workdays',array('as'=>'admin_month_workdays','uses'=>'admin@month_workdays'));
Route::get('admin/emeal_ledger_select',array('as'=>'admin_emeal_ledger_select','uses'=>'admin@emeal_ledger_select'));
Route::put('admin/emeal_ledger_report',array('as'=>'admin_emeal_ledger_report','uses'=>'admin@emeal_ledger_report'));
Route::get('admin/user_report/(:any)',array('as'=>'admin_user_report','uses'=>'admin@user_report'));
Route::get('admin/generate_balance',array('as'=>'admin_generate_balance','uses'=>'admin@generate_balance'));
Route::get('admin/regenerate_balance',array('as'=>'admin_regenerate_balance','uses'=>'admin@regenerate_balance'));
Route::get('admin/ecoupon_list',array('as'=>'admin_ecoupon_list','uses'=>'admin@ecoupon_list'));
Route::get('admin/remaining_balance',array('as'=>'admin_remaining_balance','uses'=>'admin@remaining_balance'));
Route::post('admin/jqgrid/(:any)',array('as'=>'admin_jqgrid','uses'=>'admin@jqgrid'));



Route::get('agent/proposal/(:any)',array('as'=>'agent_proposal','uses'=>'agent@proposal'));
Route::get('agent/claims',array('as'=>'agent_claims','uses'=>'agent@claims'));
Route::get('agent/proposal_print/(:any)',array('as'=>'agent_proposal_print','uses'=>'agent@proposal_print'));
Route::get('agent/ci_print/(:any)',array('as'=>'agent_ci_print','uses'=>'agent@ci_print'));
Route::get('agent/proposal_list',array('as'=>'agent_proposal_list','uses'=>'agent@proposal_list'));
Route::put('agent/save_proposal',array('uses'=>'agent@save_proposal'));
Route::get('agent/user_list',array('as'=>'agent_user_list','uses'=>'agent@user_list'));
Route::get('agent/edit_user/(:any)',array('as'=>'agent_edit_user','uses'=>'agent@edit_user'));
Route::put('agent/save_user',array('uses'=>'agent@save_user'));
Route::post('agent/ajax/(:any)',array('as'=>'agent_ajax','uses'=>'agent@ajax'));
Route::post('agent/jqgrid/(:any)',array('as'=>'agent_jqgrid','uses'=>'agent@jqgrid'));
Route::get('agent/password',array('as'=>'agent_password','uses'=>'agent@password'));
Route::put('agent/password_update',array('uses'=>'agent@password_update'));
Route::get('agent/claim_report',array('as'=>'agent_claim_report','uses'=>'agent@claim_report'));
Route::put('agent/process_claim_report',array('uses'=>'agent@process_claim_report'));
Route::get('agent/ci_issued_report',array('as'=>'agent_ci_issued_report','uses'=>'agent@ci_issued_report'));
Route::put('agent/process_ci_issued_report',array('uses'=>'agent@process_ci_issued_report'));
Route::get('agent/collection_report',array('as'=>'agent_collection_report','uses'=>'agent@collection_report'));
Route::put('agent/process_collection_report',array('uses'=>'agent@process_collection_report'));
Route::get('agent/production_report',array('as'=>'agent_production_report','uses'=>'agent@production_report'));
Route::put('agent/process_production_report',array('uses'=>'agent@process_production_report'));
Route::get('agent/renewal_report',array('as'=>'agent_renewal_report','uses'=>'agent@renewal_report'));
Route::put('agent/process_renewal_report',array('uses'=>'agent@process_renewal_report'));
Route::get('agent/lapse_report',array('as'=>'agent_lapse_report','uses'=>'agent@lapse_report'));
Route::put('agent/process_lapse_report',array('uses'=>'agent@process_lapse_report'));
Route::get('agent/ageing_report',array('as'=>'agent_ageing_report','uses'=>'agent@ageing_report'));
Route::put('agent/process_ageing_report',array('uses'=>'agent@process_ageing_report'));
Route::get('agent/performance_report',array('as'=>'agent_performance_report','uses'=>'agent@performance_report'));
Route::put('agent/process_performance_report',array('uses'=>'agent@process_performance_report'));







/*
|--------------------------------------------------------------------------
| Application 404 & 500 Error Handlers
|--------------------------------------------------------------------------
|
| To centralize and simplify 404 handling, Laravel uses an awesome event
| system to retrieve the response. Feel free to modify this function to
| your tastes and the needs of your application.
|
| Similarly, we use an event to handle the display of 500 level errors
| within the application. These errors are fired when there is an
| uncaught exception thrown in the application.
|
*/

Event::listen('404', function()
{
	return Response::error('404');
});

Event::listen('500', function()
{
	return Response::error('500');
});

/*
|--------------------------------------------------------------------------
| Route Filters
|--------------------------------------------------------------------------
|
| Filters provide a convenient method for attaching functionality to your
| routes. The built-in before and after filters are called before and
| after every request to your application, and you may even create
| other filters that can be attached to individual routes.
|
| Let's walk through an example...
|
| First, define a filter:
|
|		Route::filter('filter', function()
|		{
|			return 'Filtered!';
|		});
|
| Next, attach the filter to a route:
|
|		Route::get('/', array('before' => 'filter', function()
|		{
|			return 'Hello World!';
|		}));
|
*/

Route::filter('before', function()
{
	// Do stuff before every request to your application...
});

Route::filter('after', function($response)
{
	// Do stuff after every request to your application...
});

Route::filter('csrf', function()
{
	if (Request::forged()) return Response::error('500');
});

Route::filter('auth', function()
{
	if (Auth::guest()) return Redirect::to('login');
});