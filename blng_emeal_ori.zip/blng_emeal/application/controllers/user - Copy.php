<?php
	class User_Controller extends Base_Controller {

		public $restful = true;

		public function get_index($date_from = '', $date_to = ''){			

			$headers = apache_request_headers();
 
if (!isset($headers['Authorization'])){
    header('HTTP/1.1 401 Unauthorized');
    header('WWW-Authenticate: NTLM');
    exit;
}
 
$auth = $headers['Authorization'];
 
if (substr($auth,0,5) == 'NTLM ') {
    $msg = base64_decode(substr($auth, 5));
    if (substr($msg, 0, 8) != "NTLMSSP\x00")
        die('error header not recognised');
 
    if ($msg[8] == "\x01") {
        $msg2 = "NTLMSSP\x00\x02\x00\x00\x00".
            "\x00\x00\x00\x00". // target name len/alloc
            "\x00\x00\x00\x00". // target name offset
            "\x01\x02\x81\x00". // flags
            "\x00\x00\x00\x00\x00\x00\x00\x00". // challenge
            "\x00\x00\x00\x00\x00\x00\x00\x00". // context
            "\x00\x00\x00\x00\x00\x00\x00\x00"; // target info len/alloc/offset
 
        header('HTTP/1.1 401 Unauthorized');
        header('WWW-Authenticate: NTLM '.trim(base64_encode($msg2)));
        exit;
    }
    else if ($msg[8] == "\x03") {
        function get_msg_str($msg, $start, $unicode = true) {
            $len = (ord($msg[$start+1]) * 256) + ord($msg[$start]);
            $off = (ord($msg[$start+5]) * 256) + ord($msg[$start+4]);
            if ($unicode)
                return str_replace("\0", '', substr($msg, $off, $len));
            else
                return substr($msg, $off, $len);
        }
        $username = get_msg_str($msg, 36);
    }
}

			if(DB::table('memberlist')->where('username','=',$username)->count() > 0){
				$row = DB::table('memberlist')
					->where('username','=',$username)
					->first();
				$meal_balance = number_format($row->balance,2);
			}
			else {
				$meal_balance = "n/a";
			}

			if($date_from == '' && $date_to == '') {
				$from = date('Y-m').'-1';
				$next_year = date('Y') + 1;
				$to = $next_year.'-'.date('m-t');
				$from2 = '01/'.date('m/Y');
				$to2 = date('t/m/Y');
			}
			else {
				$from = DateTime::createFromFormat('dmY',$date_from)->format('Y-m-d');
				$from2 = DateTime::createFromFormat('dmY',$date_from)->format('d/m/Y');
				$toF = DateTime::createFromFormat('dmY',$date_to);
				$toF->add(new DateInterval('P1D'));
				$to = $toF->format('Y-m-d');
				$to2 = DateTime::createFromFormat('dmY',$date_to)->format('d/m/Y');
			}
			

			$result = DB::table('emealledger')
				->join('memberlist','emealledger.serialno2','=','memberlist.serialno2')
				->where('memberlist.username','=',$username)
				->where('emealledger.psda','>=',$from)
				->where('emealledger.psda','<=',$to)
				->order_by('emealledger.serialno2')
				->order_by('emealledger.psda', 'desc')
				->get(array('vendorid','emealledger.serialno2','emealledger.serviceno','emealledger.name','amount',DB::raw("CONVERT(VARCHAR(19), emealledger.psda, 120) as psda"),'transref'));
				
			$total = 0;

			$meal_ledger =  "<p style='font-weight:bold'>eCoupon Transactions for $username from $from2 to $to2</p>";

			$meal_ledger .= "<table>
			<th style='padding:10px'>Date</th>
			<th style='padding:10px'>Card No</th>
			<th style='padding:10px'>Ref Ind</th>
			<th style='padding:10px'>Holder Name</th>
			<th style='padding:10px'>Personnel No</th>
			<th style='padding:10px'>Card Ref No</th>
			<th style='padding:10px'>Vendor</th>
			<th style='padding:10px'>Trans. Ref.</th>
			<th style='padding:10px'>Amount</th>
			";

			foreach ($result as $row) {
				$row2 = DB::table('memberlist')
					->where('serviceno','=',$row->serviceno)
					->first(array('refind','cardref'));

				$meal_ledger .=  "<tr>";
				$meal_ledger .= "<td style='padding:3px'>".$row->psda."</td>";
				$meal_ledger .=  "<td style='padding:3px'>".$row2->cardref."</td>";
				$meal_ledger .=  "<td style='padding:3px'>".$row2->refind."</td>";
				$meal_ledger .=  "<td style='padding:3px'>".$row->name."</td>";
				$meal_ledger .=  "<td style='padding:3px'>".$row->serialno2."</td>";				
				$meal_ledger .=  "<td style='padding:3px'>".$row->serviceno."</td>";				
				$meal_ledger .=  "<td style='padding:3px'>".$row->vendorid."</td>";
				$meal_ledger .= "<td style='padding:3px'>".$row->transref."</td>";
				$meal_ledger .=  "<td style='text-align:right'>".number_format($row->amount,2)."</td>";
				$meal_ledger .=  "<tr/>";
				$total += $row->amount;
			}
			$total = number_format($total,2);

			$meal_ledger .=  "<tr style='font-weight:bold'><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Total:</td><td style='text-align:right'>$total</td></tr>";


			return View::make('user.index')
				->with('meal_balance',$meal_balance)
				->with('meal_ledger',$meal_ledger)
				->with('username',$username)
				->with('title','BLNG eCoupon System - eCoupon Transactions');
		}
	}
?>
