<?php

class Add_Salary_Fields {

	/**
	 * Make changes to the database.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('debtor',function($table){
			$table->decimal('salary_base',10,2);
			$table->decimal('salary_allow',10,2);
			$table->decimal('salary_tap',10,2);
			$table->decimal('salary_scp',10,2);
		});
	}

	/**
	 * Revert the changes to the database.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('debtor',function($table){
			$table->drop_column('salary_base');
			$table->drop_column('salary_allow');
			$table->drop_column('salary_tap');
			$table->drop_column('salary_scp');
		});
	}

}