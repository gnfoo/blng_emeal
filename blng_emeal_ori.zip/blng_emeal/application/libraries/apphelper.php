<?php
class AppHelper {

	public static function array_is_associative ($array)
	{
	    if ( is_array($array) && ! empty($array) )
	    {
	        for ( $iterator = count($array) - 1; $iterator; $iterator-- )
	        {
	            if ( ! array_key_exists($iterator, $array) ) { return true; }
	        }
	        return ! array_key_exists(0, $array);
	    }
	    return false;
	}

    public static function Strip($value)
	{
		if(get_magic_quotes_gpc() != 0)
	  	{
	    	if(is_array($value))  
				if ( Apphelper::array_is_associative($value) )
				// if ( $this->array_is_associative($value) )
				{
					foreach( $value as $k=>$v)
						$tmp_val[$k] = stripslashes($v);
					$value = $tmp_val; 
				}				
				else  
					for($j = 0; $j < sizeof($value); $j++)
	        			$value[$j] = stripslashes($value[$j]);
			else
				$value = stripslashes($value);
		}
		return $value;
	}

	

	public static function dateConvertToYmd($date){
		if($date != '' && $date != '0000-00-00')	$return = DateTime::createFromFormat('d/m/Y',$date)->format('Y-m-d');
		else $return='';
		return $return;
	}

	public static function dateConvertToDmy($date){
		if($date != '' && $date != '0000-00-00')	$return = DateTime::createFromFormat('Y-m-d',$date)->format('d/m/Y');
		else $return='';
		return $return;
	}

	public static function dateConvertToDmy2($date){
		if($date != '' && $date != '0000-00-00 00:00:00')	$return = DateTime::createFromFormat('Y-m-d H:i:s',$date)->format('d/m/Y');
		else $return='';
		return $return;
	}

	public static function dateConvertToYmdhis($date){
		if($date != '' && $date != '0000-00-00 00:00:00')  $return = DateTime::createFromFormat('d/m/Y H:i:s',$date)->format('Y-m-d H:i:s');
		else $return='';
		return $return;
	}

	public static function dateConvertToDmyhis($date){
		if($date != '' && $date != '0000-00-00 00:00:00')	$return = DateTime::createFromFormat('Y-m-d H:i:s',$date)->format('d/m/Y H:i:s');
		else $return='';
		return $return;
	}

	public static function drawCalendar($start_date,$no_of_months){
		$begin = DateTime::createFromFormat('dmY',$start_date);

		$end = DateTime::createFromFormat('dmY',$start_date);		
		$end->add(new DateInterval('P'.$no_of_months.'M'));

		$period = new DatePeriod($begin, DateInterval::createFromDateString('1 day'), $end);

		$period2 = new DatePeriod($begin, DateInterval::createFromDateString('1 month'), $end);

		$data = '<table id="calendar_headers">';

		$data .= '<tr><td width=230>&nbsp</td></tr>
				<tr><td width=230>&nbsp</td></tr>
				<tr><td width=230>&nbsp</td></tr>';

		$result = DB::table('debtor')->where('estatus','=','Active')->where('company','=','Bellaziz')->order_by('position','asc')->get(array('sno','cu','code'));

		for ($i=0;$i<count($result);$i++){
			$data .= "<tr><td>".$result[$i]->cu."</td></tr>";
		}

		$data .= "</table>";

		$data .= '<table id="calendar">';

		$month_row = '<tr>';
		foreach ( $period2 as $dt ) {
			$days=cal_days_in_month(CAL_GREGORIAN, $dt->format('m'), $dt->format('Y'));
			$month_row .= "<th colspan=".$days." style='text-align:center'>".$dt->format('F')."</th>";
		}
		$month_row .= '</tr>';	


		$day_row = '<tr>';
		foreach ( $period as $dt ) {
			$day_row .= '<td>'.substr($dt->format( "D" ),0,1).'</td>';
		}
		$day_row .= '</tr>';	

		$period3 = new DatePeriod($begin, DateInterval::createFromDateString('1 day'), $end);
		$date_row = '<tr>';
		foreach ( $period3 as $dt ) {
			$date_row .= '<td>'.$dt->format( "d" ).'</td>';
		}
		$date_row .= '</tr>';		

		$staffs = '';
		$result = DB::table('debtor')->where('estatus','=','Active')->where('company','=','Bellaziz')->order_by('position','asc')->get(array('sno','cu','code'));

		$period_array = array();
		for($j=0;$j<count($result);$j++){
			$period_array[$j] = new DatePeriod($begin, DateInterval::createFromDateString('1 day'), $end);
		}

		for ($i=0;$i<count($result);$i++){

			$result2 = DB::table('leave')
				->where('tpoflv','=','Business Travel')
				->where('code','=',$result[$i]->code)
				->get(array(DB::raw('date_format(starttime,"%d/%m/%Y") as starttime'),DB::raw('date_format(endtime,"%d/%m/%Y") as endtime'),'destination','lck_dur','stat1'));	

			$date_string='';	
			for ($j=0;$j<count($result2);$j++){
				$date_string .= $result2[$j]->starttime . ",";
			}	
				
			$countx = DB::table('leave')
				->where('tpoflv','=','Business Travel')
				->where('code','=',$result[$i]->code)
				->count();
				
			$staff = '';
			$staff .= "<tr>";

			$counter = 0;
			foreach ( $period_array[$i] as $dt ) {
				if($dt->format('d')=='01'){//check for business travel that goes over 1 month
					foreach($result2 as $row){
						$travel_start = DateTime::createFromFormat('d/m/Y',$row->starttime);
						$travel_end = DateTime::createFromFormat('d/m/Y',$row->endtime);
						$destination = $row->destination;
						if($row->stat1=='Pending') {
							$color = '#D69E87';
						}
						else {
							$color = '#70DBDB';
						}
						if($dt > $travel_start && $dt <= $travel_end && $travel_start<$begin){
							$counter = $travel_end->diff($dt)->format('%a')+1;
							$staff .= "<td style='background-color:$color' colspan=".$counter."id='".$result[$i]->sno."_".$dt->format("dmY")."x'>".$destination."&nbsp</td>";
						}
					}
				}

				if($counter > 0){
					$counter--;
				}
				else {
					$key = AppHelper::searchForValue($dt->format('d/m/Y'),$result2,'starttime');
					if($key != null){
						$key--;
						$counter = $result2[$key]->lck_dur-1;
						if($result2[$key]->stat1=='Pending') {
							$color = '#D69E87';
						}
						else {
							$color = '#70DBDB';
						}
						$staff .= "<td style='background-color:$color' colspan=".$result2[$key]->lck_dur."id='".$result[$i]->sno."_".$dt->format("dmY")."x'>".$result2[$key]->destination."&nbsp</td>";
					}
					else {
						if($dt->format('D') ==  'Sat' || $dt->format('D') ==  'Sun') $staff .= "<td style='background-color:white' id='".$result[$i]->sno."_".$dt->format("dmY")."'>&nbsp</td>";
						else $staff .= "<td id='".$result[$i]->sno."_".$dt->format("dmY")."'>&nbsp</td>";
					}
				}
			}
			$staff .= "</tr>";
			$staffs .= $staff;
		}

		$data .= $month_row.$day_row.$date_row.$staffs.'</table>';

		return $data;
	}

	public static function colorCalendar($start_date,$no_of_months,$type){
		$to_color = '';
		$begin = DateTime::createFromFormat('dmY',$start_date);

		$end = DateTime::createFromFormat('dmY',$start_date);		
		$end->add(new DateInterval('P'.$no_of_months.'M'));

		$query = DB::table('leavebal')
			->where('tpoflv','=',$type)
			->where('taken','>',0)
			// ->where('dafrom','>=',$begin->format('Y-m-d'))
			// ->where('dato','<',$end->format('Y-m-d'));
			->where(function($query2) use ($begin,$end){
				$query2->where('dafrom','>=',$begin->format('Y-m-d'));
				$query2->or_where('dato','<',$end->format('Y-m-d'));
				$query2->or_where('dafrom','<',$begin->format('Y-m-d'));
			});

		$result = $query->get(array('code','dafrom','dato'));

		foreach ($result as $row) {
			if(DB::table('debtor')->where('estatus','=','Active')->where('code','=',$row->code)->count()>0)
			$sno = DB::table('debtor')->where('estatus','=','Active')->where('code','=',$row->code)->first(array('sno'))->sno;
			$period = new DatePeriod(
				DateTime::createFromFormat('Y-m-d H:i:s',$row->dafrom),
				DateInterval::createFromDateString('1 day'), 
				DateTime::createFromFormat('Y-m-d H:i:s',$row->dato)->add(new DateInterval('P1D'))
			);
			foreach ( $period as $dt ) {
				$to_color.="#".$sno."_".$dt->format('dmY').",";
			}

		}

		return $to_color;
	}

	public static function colorCalendarPending($start_date,$no_of_months,$type){
		$to_color = '';
		$begin = DateTime::createFromFormat('dmY',$start_date);

		$end = DateTime::createFromFormat('dmY',$start_date);		
		$end->add(new DateInterval('P'.$no_of_months.'M'));

		if($type == 'Business Travel') $sign = '=';
		else $sign = '!=';

		$query = DB::table('leave')
			->where('stat1','=','Pending')
			->where('tpoflv',$sign,'Business Travel')
			->where(function($query2) use ($begin,$end){
				$query2->where('starttime','>=',$begin->format('Y-m-d'));
				$query2->or_where('endtime','<',$end->format('Y-m-d'));
				$query2->or_where('starttime','<',$begin->format('Y-m-d'));
			});

		$result = $query->get(array('code','starttime','endtime'));

		foreach ($result as $row) { 
			if(DB::table('debtor')->where('estatus','=','Active')->where('code','=',$row->code)->count()>0){
				$sno = DB::table('debtor')->where('estatus','=','Active')->where('code','=',$row->code)->first(array('sno'))->sno;
				$period = new DatePeriod(
					DateTime::createFromFormat('Y-m-d H:i:s',$row->starttime),
					DateInterval::createFromDateString('1 day'), 
					DateTime::createFromFormat('Y-m-d H:i:s',$row->endtime)->add(new DateInterval('P1D'))
				);
				foreach ( $period as $dt ) {
					$to_color.="#".$sno."_".$dt->format('dmY').",";
				}
			}
		}

		return $to_color;
	}

	public static function colorCalendarHoliday($start_date,$no_of_months){
		$to_color = '';
		$begin = DateTime::createFromFormat('dmY',$start_date);

		$end = DateTime::createFromFormat('dmY',$start_date);		
		$end->add(new DateInterval('P'.$no_of_months.'M'));

		$query = DB::table('public_holidays')
			->where('date','>=',$begin->format('Y-m-d'))
			->where('date','<',$end->format('Y-m-d'));

		$result = $query->get(array('date'));

		foreach ($result as $row) {
			$date = DateTime::createFromFormat('Y-m-d',$row->date)->format('dmY');
			$result2 = DB::table('debtor')->where('estatus','=','Active')->get(array('sno'));
				foreach ($result2 as $row2) {	
					$to_color.="#".$row2->sno."_".$date.",";
				}
		}

		return $to_color;
	}

	public static function getHolidays($start_date,$no_of_months){
		$to_color = '';
		$begin = DateTime::createFromFormat('dmY',$start_date);

		$end = DateTime::createFromFormat('dmY',$start_date);		
		$end->add(new DateInterval('P'.$no_of_months.'M'));

		$query = DB::table('public_holidays')
			->where('date','>=',$begin->format('Y-m-d'))
			->where('date','<',$end->format('Y-m-d'))
			->order_by('date','asc');

		$result = $query->get();

		$holiday_table = '<table class="holiday_table"><tr><th>Date</th><th>Holiday</th></tr>';

		foreach ($result as $row) {
			$holiday_table .= '<tr><td>'.DateTime::createFromFormat('Y-m-d',$row->date)->format('d/m/Y')."</td><td>".$row->description."</td></tr>";
		}

		$holiday_table .= "<table>";

		return $holiday_table;
	}

	public static function searchForValue($value, $array, $element) {
	   for ($i=0; $i < count($array); $i++) { 
	   		if($array[$i]->{$element} === $value) return $i+1;
	   	}	
	   		
	   // foreach ($array as $key => $val) {
	   //     if ($val->{$element} === $value) {
	   //         return $key;
	   //     }
	   // }
	   return null;
	}


	public static function searchForValue2($value, $array, $element) {
	   for ($i=0; $i < count($array); $i++) { 
	   		if($array[$i]->{$element} === $value) return $i+1;
	   	}	
	   return null;
	}

	public static function searchForValue3($value, $array, $element) {
	   for ($i=0; $i < count($array); $i++) { 
	   		if($array[$i][$element] === $value) return $i+1;
	   	}	
	   return null;
	}

	public static function getMenuItem($menu_item,$array){
		$index = Apphelper::searchForValue3($menu_item,$array,'type');
		if($index != null) 
			return '<a href="'.$array[$index-1]['path'].'" class="shortcut">'.
				'<i class="shortcut-icon icon-folder-open"></i>'.
				'<span class="shortcut-label">'.$menu_item.'</span>'.
				'</a>';
	}

	public static function getQualifications($array){
		$return_text = '';
		$j=0;
		for ($i=0; $i < count($array); $i++) { 
			if($array[$i]['type']=='Qualification') {
				$j++;
				$return_text .= 
				'<a href="'.$array[$i]['path'].'" class="shortcut">'.
				'<i class="shortcut-icon icon-folder-open"></i>'.
				'<span class="shortcut-label">Qualification '.$j.'</span>'.
				'</a>';
			}
		}
		return $return_text;
	}

}

?>