<?php

class Base_Controller extends Controller {

	/**
	 * Catch-all method for requests that can't be matched.
	 *
	 * @param  string    $method
	 * @param  array     $parameters
	 * @return Response
	 */

	public function __construct(){
		Asset::add('jqueryui-css', 'css/jquery-ui-1.8.11.custom.css');
		Asset::add('jqgrid-css', 'css/ui.jqgrid.css');
		Asset::add('bootstrap-css', 'css/bootstrap/bootstrap.min.css');
		Asset::add('bootstrap-responsive-css', 'css/bootstrap/bootstrap-responsive.min.css');
		Asset::add('font-awesome-css','css/bootstrap/font-awesome.min.css');
		Asset::add('fonts-css','css/fonts.css');
		Asset::add('base-admin-css','css/bootstrap/base-admin-2.css');
		Asset::add('base-admin-responsive-css','css/bootstrap/base-admin-2-responsive.css');
		Asset::add('base-admin-responsive-css','css/bootstrap/base-admin-2-responsive.css');
		Asset::add('table-theme','css/defaultTheme.css');

		Asset::add('jquery-js','js/bootstrap/jquery-1.7.2.min.js');
		Asset::add('jqueryui-js','js/jquery-ui-1.8.11.custom.min.js');
		Asset::add('jqgrid-js','js/jquery.jqGrid.min.js');
		Asset::add('jqgrid-locale','js/i18n/grid.locale-en.js');
		Asset::add('excanvas-js','js/bootstrap/excanvas.min.js');
		Asset::add('bootstrap-js','js/bootstrap/bootstrap.js');
		Asset::add('base-js','js/bootstrap/base.js');
		Asset::add('date-js','js/date.js');
		Asset::add('time-js','js/time.js');
		Asset::add('moment-js','js/moment.js');
		Asset::add('fixed-header-table-js','js/jquery.fixedheadertable.js');
		Asset::add('acounting-js','js/accounting.min.js');

		Asset::add('Saysettha OT','fonts/saysettha_ot.ttf');


		parent::__contruct();
	}

	
	public function __call($method, $parameters)
	{
		return Response::error('404');		
	}
}