<?php

	class Authors_Controller extends Base_Controller {

		public $restful = true;

		public function get_index(){
			return View::make('authors.index')
				->with('title','Authors and Books')
				->with('authors',Author::order_by('name','asc')->get());
		}

		public function get_view($id){
			return View::make('authors.view')
				->with('title','Author View Page')
				->with('author',Author::find($id));
		}

		public function get_new(){
			return View::make('authors.new')
				->with('title','Add New Author');
		}

		public function post_create(){
			$validation = Author::validate(Input::all());

			if($validation->fails()){
				return Redirect::to_route('new_author')
					->with_errors($validation)
					->with_input();
			}
			else {
				Author::create(array(
					'name' => Input::get('name'),
					'bio' => Input::get('bio')
				));

				return Redirect::to_route('authors')
					->with('message','The author was created successfully.');

			}

		}

		public function get_edit($id){
			return View::make('authors.edit')
				->with('title','Edit Author')
				->with('author',Author::find($id));
		}

		public function put_update(){
			$id = Input::get('id');
			$validation = Author::validate(Input::all());

			if ($validation->fails()){
				return Redirect::to_route('edit_author',$id)
				->with_errors($validation);
			}
			else{
				Author::update($id,array(
					'name'=>Input::get('name'),
					'bio'=>Input::get('bio')
				));
				return Redirect::to_route('author',$id)
				->with('message','Author updated successfully.');


			}
		}

		public function post_jqgrid($case){		
			switch ($case) {
				case 1:
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					if(isset($sidx))$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					if(isset($sidx))$sord = $_REQUEST['sord']; // get the direction

					if(!isset($sidx)) $sidx =1;

					$query = DB::table('authors');

					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'name':
								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					

					$count = $query->count();
					$result = $query->get();	
					

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;					

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->id;
						$response->rows[$i]['cell'] = array($row->name);
						$i++;
					}

					echo json_encode($response);
					break;
				
				case 2:
					$id=$_REQUEST['id'];
					$name = $_REQUEST['name'];
					$affected = DB::table('authors')->where('id','=',$id)->update(array('name'=>$name));
					break;
			}

			
		}
			
	}

?>