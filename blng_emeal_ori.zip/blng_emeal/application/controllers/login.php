<?php

	class Login_Controller extends Base_Controller {
		


		public $restful = true;

		public function get_index(){

			

			if(DB::table('memberlist')->where('name','=',$username)->count() > 0){
				$row = DB::table('memberlist')
					->where('name','=',$username)
					->first();
				$meal_balance = $row->balance;
			}
			else {
				$meal_balance = "n/a";
			}

			return View::make('login.index')
				->with('meal_balance',$meal_balance)
				->with('username',$username)
				->with('title','BLNG eCoupon System Login');
		}

		public function get_retrieve(){
			return View::make('login.retrieve')
				->with('title','Retrieve Password');
		}

		public function post_process(){
			//start login		

		$login = Input::get('login');    
		$password  = Input::get('password');	    

			if(DB::table('admins')->where('login','=',$login)->count() > 0){
				$row = DB::table('admins')
					->where('login','=',$login)
					->first();
				$verifypw = $row->password;
			}

	    
	    if ($password == $verifypw && $password != "" && $password != null)
	    {
			 $query = DB::table('admins')
			 	->where('login','=',Input::get('login'));
			 // $checkpw = '';	
			 if($query->count()>0) {
			 	$result = $query->first();
			 	$checkpw = $result->password;
			 	$name = $result->name;
			 	$login = $result->login;
			 	$id = $result->admin_id;
			 	Session::put('name',$name);
			 	Session::put('login',$login);
			 	Session::put('id',$id);
				return Redirect::to_route('admin_working_days_list');	
			}
			}
			// echo Input::get('password')."<br/>";
			// echo $checkpw."<br/>";
			// echo $query->count();
			// $cond = Input::get('password') == $checkpw && $query->count() >0 && $checkpw != '';
			// echo $cond;

			// if(Input::get('password') === $checkpw && $query->count() >0 && $checkpw != '') {
			// 	Session::put('name',$name);
			// 	Session::put('login',$login);
			// 	Session::put('id',$id);
			// 	return Redirect::to_route('admin_working_days_list');		
			// }



			else {
				// return Redirect::to_route('admin_working_days_list');		
				return Redirect::to_route('login')
					->with_input()
					->with('message','User is not an administrator.');
			}

			
		}

		public function post_process_retrieve(){
			$result = DB::table('debtor')
				->where('cu','like','%'.Input::get('login').'%');

			if($result->count() > 0 && Input::get('login') != ''){
				$row = $result->first(array('sno','email','cu'));
				$password = rand(10000,99999);
				DB::table('debtor')->where('sno','=',$row->sno)->update(array('lrmk'=>$password));
				$email = $row->email;
				$login = $row->cu;

				Message::send(function($message) use ($email,$password,$login)
				{
				    $message->to($email);
				    $message->from('belazizadmin@gmail.com', 'BellAziz Admin');
				    $message->subject('Password Reset');

				    $message->body(
				    	'Dear '.$login.',<br/><br/>'.
				    	'Your password has been reset to '.
				    	$password.
				    	".<br/><br/>Please login at http://10.0.0.200/hr to change your password.<br/><br/>".
				    	'BellAziz Admin'
				    );

				    $message->html(true);
				});  
				
				return Redirect::to_route('login')
					->with_input()
					->with('message','Password successfully reset and email sent. Please login and change your password.');
			}	
			else {
				return Redirect::to_route('login_retrieve')
					->with_input()
					->with('message','Incorrect username.');
			}
		}
		
		public function get_logout(){
			Session::flush();
			return Redirect::to_route('login');

		}	
	}

?>