<?php
	class User_Controller extends Base_Controller {

		public $restful = true;

		public function get_index($username = '', $serviceno = ''){			

//			$headers = apache_request_headers();
// 		$username = Input::get('login');    
//		$password  = Input::get('password');	 
//		echo $username;
$date_from = '';
$date_to = '';
			if($username == ''){$usernamex='e.g. firstname.lastname';}
			else{$usernamex=$username;}
			if(DB::table('memberlist')->where('username','=',$usernamex)->count() > 0){
				$row = DB::table('memberlist')
					->where('username','=',$usernamex)
					->where('serviceno','=',$serviceno)
					->first();
				$meal_balance = number_format($row->balance,2);
			}
			else {
				$meal_balance = "n/a";
			}

			if($date_from == '' && $date_to == '') {
				$from = date('Y-m').'-1';
				$next_year = date('Y') + 1;
				$to = $next_year.'-'.date('m-t');
				$from2 = '01/'.date('m/Y');
				$to2 = date('t/m/Y');
			}
			else {
				$from = DateTime::createFromFormat('dmY',$date_from)->format('Y-m-d');
				$from2 = DateTime::createFromFormat('dmY',$date_from)->format('d/m/Y');
				$toF = DateTime::createFromFormat('dmY',$date_to);
				$toF->add(new DateInterval('P1D'));
				$to = $toF->format('Y-m-d');
				$to2 = DateTime::createFromFormat('dmY',$date_to)->format('d/m/Y');
			}
			
			if($serviceno==$row->serviceno){ 
			$result = DB::table('emealledger')
				->join('memberlist','emealledger.serialno2','=','memberlist.serialno2')
				->where('memberlist.username','=',$usernamex)
				->where('emealledger.psda','>=',$from)
				->where('emealledger.psda','<=',$to)
				->order_by('emealledger.serialno2')
				->order_by('emealledger.psda', 'desc')
				->get(array('vendorid','emealledger.serialno2','emealledger.serviceno','emealledger.name','amount',DB::raw("CONVERT(VARCHAR(19), emealledger.psda, 120) as psda"),'transref'));
				
			$total = 0;

			$meal_ledger =  "<p style='font-weight:bold'>eCoupon Transactions for $username from $from2 to $to2</p>";

			$meal_ledger .= "<table>
			<th style='padding:10px'>Date</th>
			<th style='padding:10px'>Card No</th>
			<th style='padding:10px'>Ref Ind</th>
			<th style='padding:10px'>Holder Name</th>
			<th style='padding:10px'>Personnel No</th>
			<th style='padding:10px'>Card Ref No</th>
			<th style='padding:10px'>Vendor</th>
			<th style='padding:10px'>Trans. Ref.</th>
			<th style='padding:10px'>Amount</th>
			";

			foreach ($result as $row) {
				$row2 = DB::table('memberlist')
					->where('serviceno','=',$row->serviceno)
					->first(array('refind','cardref'));

				$meal_ledger .=  "<tr>";
				$meal_ledger .= "<td style='padding:3px'>".$row->psda."</td>";
				$meal_ledger .=  "<td style='padding:3px'>".$row2->cardref."</td>";
				$meal_ledger .=  "<td style='padding:3px'>".$row2->refind."</td>";
				$meal_ledger .=  "<td style='padding:3px'>".$row->name."</td>";
				$meal_ledger .=  "<td style='padding:3px'>".$row->serialno2."</td>";				
				$meal_ledger .=  "<td style='padding:3px'>".$row->serviceno."</td>";				
				$meal_ledger .=  "<td style='padding:3px'>".$row->vendorid."</td>";
				$meal_ledger .= "<td style='padding:3px'>".$row->transref."</td>";
				$meal_ledger .=  "<td style='text-align:right'>".number_format($row->amount,2)."</td>";
				$meal_ledger .=  "<tr/>";
				$total += $row->amount;
			}
			$total = number_format($total,2);

			$meal_ledger .=  "<tr style='font-weight:bold'><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Total:</td><td style='text-align:right'>$total</td></tr>";
			}

			return View::make('user.index')
				->with('meal_balance',$meal_balance)
				->with('meal_ledger',$meal_ledger)
				->with('username',$username)
				->with('title','BLNG eCoupon System - eCoupon Transactions');
		}
	}
?>
