<?php
	include(path('app').'/includes/IOFactory.php');
	class Admin_Controller extends Base_Controller {

		public $restful = true;

		

		public function get_working_days_list(){
			$member_list = '';
			$result = DB::table('memberlist')->order_by('serviceno')->get();
			foreach ($result as $row) {
				$member_list .= $row->serviceno.": ".$row->serviceno." ".$row->name.";";
			}
			$member_list = substr($member_list, 0,strlen($member_list)-1);

			return View::make('admin.working_days_list')
				->with('title','Working Days List')
				->with('member_list',$member_list);
		}

		public function get_members_list(){
			$total_entitlement  = number_format(DB::table('memberlist')->sum('entitlement'),2);
			$total_balance  = number_format(DB::table('memberlist')->sum('balance'),2);

			return View::make('admin.members_list')
				->with('total_entitlement',$total_entitlement)
				->with('total_balance',$total_balance)
				->with('title','Member List');			
		}

		public function get_remaining_balance(){

			return View::make('admin.remaining_balance')
				->with('title','Remaining Balance');			
		}

		public function get_ecoupon_list(){
			$vendor_list = '';
			$result = DB::table('vendorlist')->order_by('vendorid')->get();
			foreach ($result as $row) {
				$vendor_list .= $row->vendorid.": ".$row->vendorid.";";
			}
			$vendor_list = substr($vendor_list, 0,strlen($vendor_list)-1);	

			return View::make('admin.ecoupon_list')
				->with('vendor_list',$vendor_list)
				->with('title','Ecoupon List');			
		}

		public function get_members_list_archive(){
			return View::make('admin.members_list_archive')
				->with('title','Member List Archive');			
		}

		public function get_search_members($id){
			return View::make('admin.search_members')
				->with('id',$id)
				->with('title','Search Members');			
		}

		public function get_admins_list(){
			return View::make('admin.admins_list')
				->with('title','Admin List');			
		}

		public function get_vendors_list(){
			return View::make('admin.vendors_list')
				->with('title','Vendor List');			
		}

		public function get_month_workdays(){
			return View::make('admin.month_workdays')
				->with('title','Workday Settings');			
		}

		public function get_transactions_list(){
			return View::make('admin.transactions_list')
				->with('title','Transactions List');
		}

		public function get_emeal_ledger_select(){
			$vendor_list = array();
			$result = DB::table('vendorlist')->order_by('COMPANY')->get();
			foreach ($result as $row) {
				$vendor_list[$row->vendorid] = $row->vendorid;
			}

			$workcat_list = array(
					'All' => 'All',
					'Shift' => 'Shift',
					'Staff' => 'Staff',
					'Assignment' => 'Assignment'
				);

			$report_types = array(
					'Detail' => 'Detail',
					'Summary' => 'Summary'
				);

			return View::make('admin.emeal_ledger_select')
				->with('vendor_list',$vendor_list)
				->with('workcat_list',$workcat_list)
				->with('report_types',$report_types)
				->with('title','eCoupon Ledger');
		}

		public function get_user_report($id = ""){
			$row = DB::table('memberlist')->where('id','=',$id)->first();
			$name = $row->name;

			$query = DB::table('emealledger')
					->join('memberlist','emealledger.serialno2','=','memberlist.serialno2')
					->where('memberlist.id','=',$id)
					->order_by('emealledger.psda', 'desc');
			$result = $query
						->order_by('emealledger.da', 'desc')
						->get(array('emealledger.serviceno','emealledger.name','amount',DB::raw("CONVERT(VARCHAR(19), emealledger.psda, 120) as psda"),'transref'));

			echo "<p style='font-weight:bold'>eCoupon Ledger for $name</p>";

			echo "<table>";
			echo "<th style='padding:10px'>Date</th>";
			echo "<th style='padding:10px'>Card No</th>";
			echo "<th style='padding:10px'>Ref Ind</th>";
			echo "<th style='padding:10px'>Holder Name</th>";
			echo "<th style='padding:10px'>Service No</th>";
			echo "<th style='padding:10px'>Serial No</th>";
			echo "<th style='padding:10px'>Trans. Ref.</th>";
			echo "<th style='padding:10px'>Amount</th>";
			
			$total = 0;
			foreach ($result as $row) {
				$row2 = DB::table('memberlist')
					->where('serviceno','=',$row->serviceno)
					->first(array('refind','cardref','serialno2'));

				echo "<tr>";
				echo "<td style='padding:3px'>".$row->psda."</td>";
				echo "<td style='padding:3px'>".$row2->cardref."</td>";
				echo "<td style='padding:3px'>".$row2->refind."</td>";
				echo "<td style='padding:3px'>".$row->name."</td>";
				echo "<td style='padding:3px'>".$row2->serialno2."</td>";				
				echo "<td style='padding:3px'>".$row->serviceno."</td>";				
				echo "<td style='padding:3px'>".$row->transref."</td>";
				echo "<td style='text-align:right'>".number_format($row->amount,2)."</td>";
				echo "<tr/>";
				$total += $row->amount;
			}
			$total = number_format($total,2);

			echo "<tr style='font-weight:bold'><td></td><td></td><td></td><td></td><td></td><td></td><td>Total:</td><td style='text-align:right'>$total</td></tr>";

		}

		public function put_emeal_ledger_report(){
			$vendor = Input::get('vendor');
			$workcat = Input::get('workcat');			
			$report_type = Input::get('report_type');			
			$from = DateTime::createFromFormat('d/m/Y',Input::get('from'))->format('Y-m-d');
			$to = DateTime::createFromFormat('d/m/Y',Input::get('to'))->format('Y-m-d');
			$from2 = Input::get('from');
			$to2 = Input::get('to');

			if($report_type <>'Summary'){
				if($workcat=='All') {						
				$query = DB::table('emealledger')
//					->join('memberlist','emealledger.serialno2','=','memberlist.serialno2')
					->where('emealledger.vendorid','=',$vendor)
					->where('emealledger.psda','>=',$from)
					->where('emealledger.psda','<=',$to)
					->or_where('emealledger.vendorid','=',$vendor)
					->where(DB::raw('CAST(emealledger.psda AS date)'), '=', $from)
					->or_where('emealledger.vendorid','=',$vendor)
					->where(DB::raw('CAST(emealledger.psda AS date)'), '=', $to)
					->order_by('emealledger.psda', 'desc');
				}				
				else {
				$query = DB::table('emealledger')
//					->join('memberlist','emealledger.serialno2','=','memberlist.serialno2')
					->where('emealledger.vendorid','=',$vendor)
					->where('memberlist.workcat','=',$workcat)
					->where('emealledger.psda','>=',$from)
					->where('emealledger.psda','<=',$to)
					->or_where('emealledger.vendorid','=',$vendor)
					->where(DB::raw('CAST(emealledger.psda AS date)'), '=', $from)
					->or_where('emealledger.vendorid','=',$vendor)
					->where(DB::raw('CAST(emealledger.psda AS date)'), '=', $to)
					->order_by('emealledger.psda', 'desc');
				}
			}
			else {
				if($workcat=='All') {						
				$query = DB::table('emealledger')
//					->join('memberlist','emealledger.serialno2','=','memberlist.serialno2')
					->where('emealledger.vendorid','=',$vendor)
					->where('emealledger.psda','>=',$from)
					->where('emealledger.psda','<=',$to)
					->or_where('emealledger.vendorid','=',$vendor)
					->where(DB::raw('CAST(emealledger.psda AS date)'), '=', $to)
					->or_where('emealledger.vendorid','=',$vendor)
					->where(DB::raw('CAST(emealledger.psda AS date)'), '=', $from);
				}				
				else {
				$query = DB::table('emealledger')
//					->join('memberlist','emealledger.serialno2','=','memberlist.serialno2')
					->where('emealledger.vendorid','=',$vendor)
					->where('memberlist.workcat','=',$workcat)
					->where('emealledger.psda','>=',$from)
					->where('emealledger.psda','<=',$to)
					->or_where('emealledger.vendorid','=',$vendor)
					->where(DB::raw('CAST(emealledger.psda AS date)'), '=', $to)
					->or_where('emealledger.vendorid','=',$vendor)
					->where(DB::raw('CAST(emealledger.psda AS date)'), '=', $from);
				}

			}

			if($report_type == 'Summary') {
					$result = $query
						->group_by('emealledger.serviceno')
						->group_by('emealledger.name')
						->order_by('emealledger.serviceno')
						->get(array('emealledger.cardref','emealledger.refind','emealledger.serialno2','emealledger.serviceno','emealledger.name',DB::raw('sum(amount) as amount')));
				}
				else {
					$result = $query
						->order_by('emealledger.serviceno')
						->order_by('emealledger.da', 'desc')
						->get(array('emealledger.cardref','emealledger.refind','emealledger.serialno2','emealledger.serviceno','emealledger.name','amount',DB::raw("CONVERT(VARCHAR(19), emealledger.psda, 120) as psda"),'transref'));
				}
				$total = 0;
			if(Input::get('excel')=='yes'){
				$objReader = PHPExcel_IOFactory::createReader('Excel5');
        		if($report_type == 'Detail') $objPHPExcel = $objReader->load(path('app').'templates/emeal_ledger_detail.xls');   	
        		if($report_type == 'Summary') $objPHPExcel = $objReader->load(path('app').'templates/emeal_ledger_summary.xls');   	
        	

				$baseRow = 3;
				$i=0;
				$sheet = $objPHPExcel->getActiveSheet();

				$sheet
						->setCellValue('A1', "eCoupon Ledger for $vendor from $from2 to $to2");

				if($report_type == 'Detail') {
					foreach ($result as $row) {
//						$row2 = DB::table('memberlist')
//							->where('serviceno','=',$row->serviceno)
//							->first(array('refind','cardref','serialno2'));

						$current_row = $baseRow + $i;
						$sheet
							->setCellValue('A'.$current_row, $row->psda)
//							->setCellValue('B'.$current_row, $row->cardref)
							->setCellValue('C'.$current_row, $row->refind)
							->setCellValue('D'.$current_row, $row->name)
							->setCellValue('E'.$current_row, $row->serialno2)
							->setCellValue('F'.$current_row, $row->serviceno)
							->setCellValue('G'.$current_row, $vendor)
							->setCellValue('H'.$current_row, $row->transref)
							->setCellValue('I'.$current_row, number_format($row->amount,2));
						$i++;

						$total += $row->amount;
					}
					$current_row = $baseRow + $i;
					$sheet
						->setCellValue('H'.$current_row, 'Total:')
						->setCellValue('I'.$current_row, $total);


				}
				else {
					foreach ($result as $row) {
						$row2 = DB::table('memberlist')
							->where('serviceno','=',$row->serviceno)
							->first(array('refind','cardref','serialno2'));

						$current_row = $baseRow + $i;
						$sheet
							->setCellValue('A'.$current_row, $row->cardref)
							->setCellValue('B'.$current_row, $row->refind)
							->setCellValue('C'.$current_row, $row->name)
							->setCellValue('D'.$current_row, $row->serialno2)
							->setCellValue('E'.$current_row, $row->serviceno)
							->setCellValue('F'.$current_row, $vendor)
							->setCellValue('G'.$current_row, number_format($row->amount,2));
						$i++;

						$total += $row->amount;
					}

					$current_row = $baseRow + $i;
					$sheet
						->setCellValue('F'.$current_row, 'Total:')
						->setCellValue('G'.$current_row, $total);
				}			
				
				// Set active sheet index to the first sheet, so Excel opens this as the first sheet
				$objPHPExcel->setActiveSheetIndex(0);

				$filename = 'emeal_ledger_report'.date('YmdHis');
				// Redirect output to a client’s web browser (Excel5)
				header('Content-Type: application/vnd.ms-excel');
				header('Content-Disposition: attachment;filename="'.$filename.'.xls"');
				header('Cache-Control: max-age=0');
				// If you're serving to IE 9, then the following may be needed
				header('Cache-Control: max-age=1');

				// If you're serving to IE over SSL, then the following may be needed
				header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
				header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
				header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
				header ('Pragma: public'); // HTTP/1.0

				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
				ob_end_clean();
				$objWriter->save('php://output');
			}

			else {
				

				echo "<p style='font-weight:bold'>eCoupon Ledger for $vendor from $from2 to $to2</p>";

				echo "<table>";
				if($report_type == 'Detail') echo "<th style='padding:10px'>Date</th>";
//				echo "<th style='padding:10px'>Card No</th>";
				echo "<th style='padding:10px'>Ref Ind</th>";
				echo "<th style='padding:10px'>Holder Name</th>";
				echo "<th style='padding:10px'>Service No</th>";
				echo "<th style='padding:10px'>Serial No</th>";
				echo "<th style='padding:10px'>Vendor</th>";
				if($report_type == 'Detail') echo "<th style='padding:10px'>Trans. Ref.</th>";
				echo "<th style='padding:10px'>Amount</th>";
				

				foreach ($result as $row) {
//					$row2 = DB::table('memberlist')
//						->where('serviceno','=',$row->serviceno)
//						->first(array('refind','cardref','serialno2'));

					echo "<tr>";
					if($report_type == 'Detail') echo "<td style='padding:3px'>".$row->psda."</td>";
//					echo "<td style='padding:3px'>".$row->cardref."</td>";
					echo "<td style='padding:3px'>".$row->refind."</td>";
					echo "<td style='padding:3px'>".$row->name."</td>";
					echo "<td style='padding:3px'>".$row->serialno2."</td>";				
					echo "<td style='padding:3px'>".$row->serviceno."</td>";				
					echo "<td style='padding:3px'>".$vendor."</td>";
					if($report_type == 'Detail') echo "<td style='padding:3px'>".$row->transref."</td>";
					echo "<td style='text-align:right'>".number_format($row->amount,2)."</td>";
					echo "<tr/>";
					$total += $row->amount;
				}
				$total = number_format($total,2);

				if($report_type == 'Summary') echo "<tr style='font-weight:bold'><td></td><td></td><td></td><td></td><td></td><td>Total:</td><td style='text-align:right'>$total</td></tr>";
				else echo "<tr style='font-weight:bold'><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Total:</td><td style='text-align:right'>$total</td></tr>";
			}
		}

		public function get_generate_balance(){
			$current_month = Date('Ym');

			$row = DB::table('month_workdays')
					->where('month','=',$current_month)
					->where('workcat','=','Shift')
					->first();
			$shift_workdays = $row->workdays;		
			$balance = $shift_workdays * 3;


			$result = DB::table('memberlist')
						->where('workcat','=','Shift')
						->get();
			foreach ($result as $row) {
				DB::table('memberlist')
				->where('id','=',$row->id)
				->update(
						array(
							'balance'=>$balance,
							'entitlement'=>$balance
					));
				DB::table('workdaystable')
				->insert(array(
					'serviceno' => $row->serialno2,
					'name' => $row->name,
					'monthyr' => $current_month,
					'workdays' => $shift_workdays,
					));
			}

			$row = DB::table('month_workdays')
					->where('month','=',$current_month)
					->where('workcat','=','Staff')
					->first();
			$permanent_workdays = $row->workdays;		
			$balance = $permanent_workdays * 3;


			$result = DB::table('memberlist')
						->where('workcat','=','Staff')
						->get();
			foreach ($result as $row) {
				DB::table('memberlist')
				->where('id','=',$row->id)
				->update(
						array(
							'balance'=>$balance,
							'entitlement'=>$balance
					));
				DB::table('workdaystable')
				->insert(array(
					'serviceno' => $row->serialno2,
					'name' => $row->name,
					'monthyr' => $current_month,
					'workdays' => $permanent_workdays,
					));
			}

			$row = DB::table('month_workdays')
					->where('month','=',$current_month)
					->where('workcat','=','Assignment')
					->first();
			$shift_workdays = $row->workdays;		
			$balance = $shift_workdays * 3;


			$result = DB::table('memberlist')
						->where('workcat','=','Assignment')
						->get();
			foreach ($result as $row) {
				DB::table('memberlist')
				->where('id','=',$row->id)
				->update(
						array(
							'balance'=>$balance,
							'entitlement'=>$balance
					));
				DB::table('workdaystable')
				->insert(array(
					'serviceno' => $row->serialno2,
					'name' => $row->name,
					'monthyr' => $current_month,
					'workdays' => $shift_workdays,
					));
			}


		}

		public function get_regenerate_balance(){
//			$current_month = Date('Ym');
//			$increase_month = date('m') + 1;
//			$current_month = Date('Y'.$increase_month);

			$current_month = Date('Ym');
			$increase_month = date('m') + 1;
			$increase_month = sprintf('%02d', $increase_month);
			$current_month = Date('Y'.$increase_month);
  			echo $current_month;

			$row = DB::table('month_workdays')
					->where('month','=',$current_month)
					->where('workcat','=','Shift')
					->first();
			$shift_workdays = $row->workdays;		
			$balance = $shift_workdays * 3;


			$result = DB::table('memberlist')
						->where('workcat','=','Shift')
						->get();

			foreach ($result as $row) {
				//insert old balance into emealledger
				$row2 = DB::table('memberlist')
					->where('id','=',$row->id)
					->first();
				if($row2->balance != 0){
//					DB::table('emealledger')
//						->insert(array(
//								'serviceno' => $row2->serviceno,
//								'name' => $row2->name,
//								'amount' => round($row2->balance*-1,2),
//								'psda' => date('Y-m-d H:i:s'),
//								'refind' => $row2->refind
//							));
					DB::table('memberlist')
						->where('id','=',$row->id)
						->update(array('balance'=>0));
				}
				//end insert old balance


				DB::table('memberlist')
				->where('id','=',$row->id)
				->update(
						array(
							'balance'=>$balance,
							'entitlement'=>$balance
					));
				DB::table('workdaystable')
				->insert(array(
					'serviceno' => $row->serialno2,
					'name' => $row->name,
					'monthyr' => $current_month,
					'workdays' => $shift_workdays,
					));

			echo $balance;
			}


			$row = DB::table('month_workdays')
					->where('month','=',$current_month)
					->where('workcat','=','Staff')
					->first();
			$permanent_workdays = $row->workdays;		
			$balance = $permanent_workdays * 3;


			$result = DB::table('memberlist')
						->where('workcat','=','Staff')
						->get();


			foreach ($result as $row) {

				//insert old balance into emealledger
				$row2 = DB::table('memberlist')
					->where('id','=',$row->id)
					->first();
				if($row2->balance != 0){
//					DB::table('emealledger')
//						->insert(array(
//								'serviceno' => $row2->serviceno,
//								'name' => $row2->name,
//								'amount' => round($row2->balance*-1,2),
//								'psda' => date('Y-m-d H:i:s'),
//								'refind' => $row2->refind
//							));
					DB::table('memberlist')
						->where('id','=',$row->id)
						->update(array('balance'=>0));
				}
				//end insert old balance

				DB::table('memberlist')
				->where('id','=',$row->id)
				->update(
						array(
							'balance'=>$balance,
							'entitlement'=>$balance
					));
				DB::table('workdaystable')
				->insert(array(
					'serviceno' => $row->serialno2,
					'name' => $row->name,
					'monthyr' => $current_month,
					'workdays' => $permanent_workdays,
					));
			}

			$row = DB::table('month_workdays')
					->where('month','=',$current_month)
					->where('workcat','=','Assignment')
					->first();
			$shift_workdays = $row->workdays;		
			$balance = $shift_workdays * 3;


			$result = DB::table('memberlist')
						->where('workcat','=','Assignment')
						->get();
			foreach ($result as $row) {
				//insert old balance into emealledger
				$row2 = DB::table('memberlist')
					->where('id','=',$row->id)
					->first();
				if($row2->balance != 0){
//					DB::table('emealledger')
//						->insert(array(
//								'serviceno' => $row2->serviceno,
//								'name' => $row2->name,
//								'amount' => round($row2->balance*-1,2),
//								'psda' => date('Y-m-d H:i:s'),
//								'refind' => $row2->refind
//							));
					DB::table('memberlist')
						->where('id','=',$row->id)
						->update(array('balance'=>0));
				}
				//end insert old balance

				DB::table('memberlist')
				->where('id','=',$row->id)
				->update(
						array(
							'balance'=>$balance,
							'entitlement'=>$balance
					));
				DB::table('workdaystable')
				->insert(array(
					'serviceno' => $row->serialno2,
					'name' => $row->name,
					'monthyr' => $current_month,
					'workdays' => $shift_workdays,
					));
			}



			echo "
				<head><title>EMEAL SCHEDULED TASK</title></head>
			";


		}



		public function post_jqgrid($case){
			switch($case) {
				case 1: //fetch members
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					if(isset($sidx))$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					if(isset($sidx))$sord = $_REQUEST['sord']; // get the direction

					if(!isset($sidx)) $sidx ='id';
					if(!isset($sord)) $sord ='asc';

					// $sidx = "";
					// $sord = "";

					$query = DB::table('memberlist');
								
					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'name':
							case 'serviceno':
							case 'refind':
							case 'serialno2':
							case 'username':
								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					
					$count = $query->count();				

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;

			        $result = 
			        	$query
			        	->order_by($sidx,$sord)
			        	->take($limit)
			        	->skip($start)
			        	->get();						

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->id;
						$response->rows[$i]['cell'] = array(
								$row->refind,
								$row->name,
								$row->serialno2,
								$row->serviceno,
								$row->cardref,
								$row->workcat,
								$row->datecreated,
								$row->dateend,
								$row->entitlement,
								number_format($row->balance,2),
								$row->username,
							);
						$i++;
					}

					echo json_encode($response);	

				break;

				case 2: //add/edit members
					$id=$_REQUEST['id'];
					$name=$_REQUEST['name'];
					$workcat=$_REQUEST['workcat'];
					$serviceno=$_REQUEST['serviceno'];
					$refind=$_REQUEST['refind'];
					$cardref=$_REQUEST['cardref'];
					$serialno2=$_REQUEST['serialno2'];
					$dateend=$_REQUEST['dateend'];
					$username=$_REQUEST['username'];

					$data = array(
								'serialno2' => $serialno2,
								'name' => $name,
								'workcat' => $workcat,
								'refind' => $refind,
								'cardref' => $cardref,
								'serviceno' => $serviceno,
								'dateend' => $dateend,
								'username' => $username,

						);

					if($id=='_empty'){
						$data['datecreated'] = Date('Y-m-d H:i:s');
						$data['balance'] = 0;
						DB::table('memberlist')
						->insert($data);
					}
					else{
						DB::table('memberlist')
							->where('id','=',$id)
							->update($data);
					} 
				break;

				case 3: //delete member
					$id = $_REQUEST['id'];

					$row = DB::table("memberlist")->where('id','=',$id)->first();
					DB::table('memberlist_archive')->insert(array(
							'id' => $row->id,
							'serviceno' => $row->serviceno,
							'serialno2' => $row->serialno2,
							'name' => $row->name,
							'workcat' => $row->workcat,
							'refind' => $row->refind,
							'cardref' => $row->cardref,
							'datecreated' => $row->datecreated,
							'balance' => $row->balance,
							'dateend' => $row->dateend,
							'username' => $row->username,

						));

					DB::table('memberlist')
							->where('id','=',$id)
							->delete();

				break;

				case 4: //fetch workdays
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					if(isset($sidx))$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					if(isset($sidx))$sord = $_REQUEST['sord']; // get the direction

					if(!isset($sidx)) $sidx ='id';
					if(!isset($sord)) $sord ='asc';

					// $sidx = "";
					// $sord = "";

					$query = DB::table('workdaystable')
						->where('workdaystable.serviceno','!=','');
						//->where('memberlist.serialno2','!=','')
						//->join('memberlist','workdaystable.serviceno','=','memberlist.serialno2');
								
					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'serviceno':
							case 'monthyr':
							case 'name':
								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					
					$count = $query->count();				

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;

			        $result = 
			        	$query
			        	->order_by($sidx,$sord)
			        	->take($limit)
			        	->skip($start)
			        	->get(array('workdaystable.id','workdaystable.serviceno','name','monthyr','workdays'));						

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->id;
						$response->rows[$i]['cell'] = array(
								$row->id,
								$row->serviceno,
								$row->name,
								$row->monthyr,
								$row->workdays,
							);
						$i++;
					}

					echo json_encode($response);	

				break;

				case 5: //add/edit working_days
					$id=$_REQUEST['id'];
					$serviceno=$_REQUEST['serviceno'];
					$monthyr=$_REQUEST['monthyr'];
					$workdays=$_REQUEST['workdays'];

					$data = array(
								'serviceno' => $serviceno,
								'monthyr' => $monthyr,
								'workdays' => $workdays,
						);

					if($id=='_empty'){
						DB::table('workdaystable')
						->insert($data);

						$row = DB::table('memberlist')->where('serialno2','=',$serviceno)->first();
						$balance = $row->balance;
						$new_balance = $balance + $workdays*3;

						$row = DB::table('memberlist')->where('serialno2','=',$serviceno)->first();
						$entitlement = $row->entitlement;
						$new_entitlement = $entitlement + $workdays*3;
												
						DB::table('memberlist')
						->where('serialno2','=',$serviceno)
						->update(array('entitlement'=>$new_entitlement));

						DB::table('memberlist')
						->where('serialno2','=',$serviceno)
						->update(array('balance'=>$new_balance));
					}
					else{
						DB::table('workdaystable')
							->where('id','=',$id)
							->update($data);
					} 
				break;

				case 6: //delete member
					$id = $_REQUEST['id'];
					DB::table('workdaystable')
							->where('id','=',$id)
							->delete();
				break;

				case 7: //reset balance
					DB::table('memberlist')->update(array('balance'=>0,'entitlement'=>0));
				break;

				case 8: //fetch admins
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					if(isset($sidx))$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					if(isset($sidx))$sord = $_REQUEST['sord']; // get the direction

					if(!isset($sidx)) $sidx ='admin_id';
					if(!isset($sord)) $sord ='asc';

					// $sidx = "";
					// $sord = "";

					$query = DB::table('admins');
								
					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'login':
							case 'name':
								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					
					$count = $query->count();				

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;

			        $result = 
			        	$query
			        	->order_by($sidx,$sord)
			        	->take($limit)
			        	->skip($start)
			        	->get();						

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->admin_id;
						$response->rows[$i]['cell'] = array(
								$row->name,
								$row->login,
								$row->password,
							);
						$i++;
					}

					echo json_encode($response);	

				break;

				case 9: //add/edit admins
					$id=$_REQUEST['id'];
					$name=$_REQUEST['name'];
					$login=$_REQUEST['login'];
					$password=$_REQUEST['password'];

					$data = array(
								'name' => $name,
								'login' => $login,
								'password' => $password,
						);

					if($id=='_empty'){
						DB::table('admins')
						->insert($data);
						
					}
					else{
						DB::table('admins')
							->where('admin_id','=',$id)
							->update($data);
					} 
				break;

				case 10: //delete admins
					$id = $_REQUEST['id'];
					DB::table('admins')
							->where('admin_id','=',$id)
							->delete();
				break;

				case 11: //fetch vendors
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					if(isset($sidx))$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					if(isset($sidx))$sord = $_REQUEST['sord']; // get the direction

					if(!isset($sidx)) $sidx ='id';
					if(!isset($sord)) $sord ='asc';

					// $sidx = "";
					// $sord = "";

					$query = DB::table('vendorlist');
								
					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'login':
							case 'name':
							case 'vendorid':
							case 'company':
								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					
					$count = $query->count();				

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;

			        $result = 
			        	$query
			        	->order_by($sidx,$sord)
			        	->take($limit)
			        	->skip($start)
			        	->get();						

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->id;
						$response->rows[$i]['cell'] = array(
								$row->name,
								$row->login,
								$row->vendorid,
								$row->password,
								$row->company,
							);
						$i++;
					}

					echo json_encode($response);	

				break;

				case 12: //add/edit working_days
					$id=$_REQUEST['id'];
					$name=$_REQUEST['name'];
					$login=$_REQUEST['login'];
					$password=$_REQUEST['password'];
					$vendorid=$_REQUEST['vendorid'];
					$company=$_REQUEST['company'];

					$data = array(
								'name' => $name,
								'login' => $login,
								'password' => $password,
								'vendorid' => $vendorid,
								'company' => $company,
						);

					if($id=='_empty'){
						DB::table('vendorlist')
						->insert($data);
						
					}
					else{
						DB::table('vendorlist')
							->where('id','=',$id)
							->update($data);
					} 
				break;

				case 13: //delete member
					$id = $_REQUEST['id'];
					DB::table('vendorlist')
							->where('id','=',$id)
							->delete();
				break;

				case 14: //fetch workday settings
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					if(isset($sidx))$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					if(isset($sidx))$sord = $_REQUEST['sord']; // get the direction

					if(!isset($sidx)) $sidx ='id';
					if(!isset($sord)) $sord ='asc';

					// $sidx = "";
					// $sord = "";

					$query = DB::table('month_workdays');
								
					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'login':
							case 'name':
							case 'vendorid':
							case 'company':
								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					
					$count = $query->count();				

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;

			        $result = 
			        	$query
			        	->order_by($sidx,$sord)
			        	->take($limit)
			        	->skip($start)
			        	->get();						

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->id;
						$response->rows[$i]['cell'] = array(
								$row->month,
								$row->workcat,
								$row->workdays,
								$row->remarks,
								$row->posted_by,
							);
						$i++;
					}

					echo json_encode($response);	

				break;

				case 15: //add/edit workday settings
					$id=$_REQUEST['id'];
					$month=$_REQUEST['month'];
					$workcat=$_REQUEST['workcat'];
					$workdays=$_REQUEST['workdays'];
					$remarks=$_REQUEST['remarks'];

					$data = array(
								'month' => $month,
								'workcat' => $workcat,
								'workdays' => $workdays,
								'remarks' => $remarks,
						);

					if($id=='_empty'){
						$data['posted_by'] = Session::get('login');
						DB::table('month_workdays')
						->insert($data);
						
					}
					else{
						DB::table('month_workdays')
							->where('id','=',$id)
							->update($data);
					} 
				break;

				case 16: //delete workday setting
					$id = $_REQUEST['id'];
					DB::table('month_workdays')
							->where('id','=',$id)
							->delete();
				break;

				case 17: //search members
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					if(isset($sidx))$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					if(isset($sidx))$sord = $_REQUEST['sord']; // get the direction

					if(!isset($sidx)) $sidx ='id';
					if(!isset($sord)) $sord ='asc';

					// $sidx = "";
					// $sord = "";

					$query = DB::table('memberlist');
								
					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'serialno2':
							case 'name':

								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					
					$count = $query->count();				

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;

			        $result = 
			        	$query
			        	->order_by($sidx,$sord)
			        	->take($limit)
			        	->skip($start)
			        	->get();						

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->id;
						$response->rows[$i]['cell'] = array(
								$row->serialno2,
								$row->name,
								$row->refind,
								$row->serialno2,
							);
						$i++;
					}

					echo json_encode($response);	
				break;

				case 19: //fetch members archive
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					if(isset($sidx))$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					if(isset($sidx))$sord = $_REQUEST['sord']; // get the direction

					if(!isset($sidx)) $sidx ='id';
					if(!isset($sord)) $sord ='asc';

					// $sidx = "";
					// $sord = "";

					$query = DB::table('memberlist_archive');
								
					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'name':
							case 'serviceno':
							case 'refind':
								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					
					$count = $query->count();				

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;

			        $result = 
			        	$query
			        	->order_by($sidx,$sord)
			        	->take($limit)
			        	->skip($start)
			        	->get();						

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->id;
						$response->rows[$i]['cell'] = array(
								$row->refind,
								$row->name,
								$row->serialno2,
								$row->serviceno,
								$row->cardref,
								$row->workcat,
								$row->datecreated,
								$row->dateend,
								$row->entitlement,
								$row->balance,
							);
						$i++;
					}

					echo json_encode($response);	

				break;

				case 20: //fetch ecoupon
					$page = $_REQUEST['page']; // get the requested page
					$limit = $_REQUEST['rows']; // get how many rows we want to have into the grid

					$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
					$sord = $_REQUEST['sord']; // get the direction

					

					// $sidx = "";
					// $sord = "";

					$query = DB::table('emealledger');
								
					$sarr = AppHelper::Strip($_REQUEST);
					foreach( $sarr as $k=>$v) {
						switch ($k) {
							case 'name':
							case 'serviceno':
							case 'refind':
							case 'serialno2':
							case 'transref':
							case 'vendorid':
								$query = $query->where($k,'like',"%$v%");
								break;
							case 'x';
								$wh .= " AND ".$k." = ".$v;
								break;
						}
					}			
					
					$count = $query->count();				

					if( $count >0 ) {
						$total_pages = ceil($count/$limit);
					} else {
						$total_pages = 0;
					}
			        if ($page > $total_pages) $page=$total_pages;
					$start = $limit*$page - $limit; // do not put $limit*($page - 1)
			        if ($start<0) $start = 0;

			        $result = 
			        	$query
			        	->order_by($sidx,$sord)
			        	->take($limit)
			        	->skip($start)
			        	->get();						

					$response = new stdClass();
					$response->page = $page;
			        $response->total = $total_pages;
			        $response->records = $count;
			        $response->rows = array();

			        $i=0;
					foreach ($result as $row){
						$response->rows[$i]['id'] = $row->id;
						$response->rows[$i]['cell'] = array(
								$row->id,
								$row->psda,
								$row->serviceno,
								$row->name,
								$row->refind,
								$row->serialno2,
								$row->vendorid,
								$row->transref,
								number_format($row->amount,2),
							);
						$i++;
					}

					echo json_encode($response);		
				break;

				case 21: //add/edit ecoupon
					$id = $_REQUEST['id'];
					$serviceno = $_REQUEST['serviceno'];
					$name = $_REQUEST['name'];
					$refind = $_REQUEST['refind'];
					$serialno2 = $_REQUEST['serialno2'];
					$vendorid = $_REQUEST['vendorid'];
					$amount = $_REQUEST['amount'];


					$data = array(
							'serviceno' => $serviceno,
							'name' => $name,
							'refind' => $refind,
							'serialno2' => $serialno2,
							'vendorid' => $vendorid,
							'amount' => $amount,
						);

					if($id=='_empty'){
						$header = DB::table('vendorlist')->where('vendorid','=',$vendorid)->first()->header;
						// $current_ref = DB::table('emealledger')->where('transref','like',"$header%")->max('transref');
						$current_ref = DB::table('emealledger')->where('transref','like',"X%")->max('transref');
						$next_ref = intval(substr($current_ref, 1,strlen($current_ref)));
						$next_ref++;
						$next_ref = 'X'."".sprintf('%07d',$next_ref);
						// $next_ref = '$header'."".sprintf('%07d',$next_ref);
						$data['psda'] = Date('Y-m-d H:i:s');
						$data['transref'] = $next_ref;
						DB::table('emealledger')
						->insert($data);

						$current_balance = DB::table('memberlist')->where('serialno2','=',$serviceno)->first()->balance;
						$new_balance = $current_balance - $amount;
						DB::table('memberlist')->where('serialno2','=',$serviceno)->update(array('balance'=>$new_balance));
					}
					else{
						// DB::table('emealledger')
							// ->where('id','=',$id)
							// ->update($data);
					} 
				
				break;

				case 22: //delete ecoupon
				break;

				case 23:
					$monthyear = $_REQUEST['month'];

					$date = DateTime::createFromFormat('Ymd',$monthyear."01");
					$date2 = DateTime::createFromFormat('Ymd',$monthyear."01");

					$date2 = $date2->add(new DateInterval('P1M'));	

					$sum_workdays = DB::table('workdaystable')->where('monthyr','=',$monthyear)->sum('workdays');
					$sum_entitled = $sum_workdays * 3;

					$no_of_pax = DB::table('workdaystable')->where('monthyr','=',$monthyear)->distinct('serviceno')->count('serviceno');

//->distinct('staffname') before count

					$sum_spent = DB::table('emealledger')
							->where('psda','>=',$date->format('Y-m-d'))
							->where('psda','<',$date2->format('Y-m-d'))
							->sum('amount');

					$remaining_balance = $sum_entitled - $sum_spent;

					echo "Month: ".$date->format('M Y')."<br/>";
					echo "No. of People: ".number_format($no_of_pax)."<br/>";
					echo "Entitled: ".number_format($sum_entitled).", Spent: ".number_format(round($sum_spent,2)).", Balance: ".number_format(round($remaining_balance,2));		


				break;
			}
		}
	}
?>
